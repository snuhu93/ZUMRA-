# ZUMRA Media Setup

ZUMRA uploads post photos and videos to a Supabase Storage bucket named `post-media`.

The app code is already configured to use that exact bucket. Supabase Storage requires the bucket to exist and upload policies to permit authenticated users to insert files.

If SQL Editor is not available, create the bucket from **Storage → New Bucket**:

- Bucket name: `post-media`
- Public bucket: **ON** (ZUMRA posts display media using public URLs)

Then add Storage policies for `post-media` allowing:
- authenticated users: INSERT into their own `<user-id>/...` folder
- authenticated users: UPDATE their own files
- authenticated users: DELETE their own files
- public: SELECT/read files

The migration file `supabase/migrations/20260817153000_create_post_media_bucket.sql` contains the exact SQL for these settings if SQL access becomes available later.
