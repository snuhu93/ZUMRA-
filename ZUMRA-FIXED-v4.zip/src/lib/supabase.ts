import { createClient } from '@supabase/supabase-js'

// This app uses Supabase's current key format exclusively:
//   VITE_SUPABASE_URL             - project URL
//   VITE_SUPABASE_PUBLISHABLE_KEY - client-safe key (sb_publishable_...)
//
// There is intentionally NO fallback to the older VITE_SUPABASE_ANON_KEY
// variable here. A previous version of this file fell back to that name,
// which caused production to silently pick up a stale key value from a
// committed .env file instead of the correct key configured in Netlify
// (Vite only lets a platform env var override a .env file value when the
// variable NAME matches exactly — a differently-named leftover variable
// is not overridden and gets built in as-is). Keeping a single source of
// truth for the key name avoids that class of bug entirely.
//
// .trim() guards against a trailing newline/space being pasted into an
// env-var UI, which otherwise silently invalidates an SDK request even
// though the key "looks" correct on screen.
const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim() ?? ''
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined)?.trim() ?? ''

if (!supabaseUrl || !supabaseAnonKey) {
  console.error(
    'Missing Supabase env vars. Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY.'
  )
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
})

export type Profile = {
  id: string
  username: string
  full_name: string
  bio: string
  avatar_url: string | null
  created_at: string
  updated_at: string
}

export type Post = {
  id: string
  user_id: string
  content: string
  media_url: string | null
  media_type: 'text' | 'image' | 'video'
  created_at: string
}

export type Comment = {
  id: string
  post_id: string
  user_id: string
  content: string
  created_at: string
}

export type Notification = {
  id: string
  user_id: string
  actor_id: string | null
  type: 'like' | 'comment' | 'follow' | 'message'
  post_id: string | null
  read: boolean
  created_at: string
}
