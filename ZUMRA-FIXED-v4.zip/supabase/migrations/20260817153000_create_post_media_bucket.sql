-- ZUMRA post media storage bucket
-- Creates the bucket used by CreatePost.tsx so media uploads do not fail with
-- "Bucket not found".

insert into storage.buckets (id, name, public)
values ('post-media', 'post-media', true)
on conflict (id) do update set public = true;

drop policy if exists "post_media_public_read" on storage.objects;
create policy "post_media_public_read"
on storage.objects for select
to public
using (bucket_id = 'post-media');

drop policy if exists "post_media_auth_insert" on storage.objects;
create policy "post_media_auth_insert"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'post-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "post_media_owner_update" on storage.objects;
create policy "post_media_owner_update"
on storage.objects for update
to authenticated
using (
  bucket_id = 'post-media'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'post-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "post_media_owner_delete" on storage.objects;
create policy "post_media_owner_delete"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'post-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);
