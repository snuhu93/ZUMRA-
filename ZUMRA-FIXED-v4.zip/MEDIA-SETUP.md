# ZUMRA Media Upload — Setup & Root Cause

## Why "Media storage is not configured" happens

ZUMRA's frontend code and the `post-media` storage bucket migration are
**both correct** in this project. The error happens because **Netlify only
builds and deploys the React app — it never runs Supabase SQL migrations.**

Files in `supabase/migrations/` are just SQL scripts sitting in your Git
repo. They are not executed automatically by:
- `netlify.toml` / the Netlify build (`npm run build`)
- pushing to GitHub
- deploying to Netlify

They only take effect once you apply them to your **live Supabase
project's database**, using one of the two methods below. If that step is
skipped, the `post-media` bucket never actually gets created in Supabase,
so every upload fails with "Bucket not found," which the app surfaces as
the "Media storage is not configured" message.

## Fix: apply the migration to your Supabase project

You only need to do this once per Supabase project (and again any time you
add a new migration file).

### Option A — Supabase Dashboard SQL Editor (easiest, no CLI needed)

1. Go to your project at https://supabase.com/dashboard
2. Open **SQL Editor** → **New query**
3. Open `supabase/migrations/20260817153000_create_post_media_bucket.sql`
   from this project, copy its full contents, paste into the SQL editor
4. Click **Run**
5. Confirm success: go to **Storage** in the sidebar — you should see a
   bucket named exactly `post-media`, marked **Public**

### Option B — Supabase CLI

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

This applies all pending migrations in `supabase/migrations/`, including
the `post-media` bucket migration, in order.

## What the migration does

`supabase/migrations/20260817153000_create_post_media_bucket.sql`:

- Creates (or updates) a storage bucket with id/name **`post-media`**,
  set to **public** (required so uploaded photos/videos can be displayed
  via public URLs in the feed, exactly as `CreatePost.tsx` expects)
- Adds Storage RLS policies on `storage.objects` scoped to that bucket:
  - `post_media_public_read` — anyone (`public`) can `SELECT`/read files,
    so images/videos render in the feed for all visitors
  - `post_media_auth_insert` — `authenticated` users can `INSERT`
    (upload) only into a folder path prefixed with their own `auth.uid()`
    (matches the app's upload path: `${user.id}/${uuid}.${ext}`)
  - `post_media_owner_update` — `authenticated` users can `UPDATE` only
    their own files (same folder-ownership check)
  - `post_media_owner_delete` — `authenticated` users can `DELETE` only
    their own files (same folder-ownership check)

The migration is written with `on conflict do update` and
`drop policy if exists` before each `create policy`, so it's safe to
re-run — it won't fail or duplicate anything if the bucket/policies
already partially exist.

## Frontend upload code

`src/screens/CreatePost.tsx` uploads to and reads from the bucket using
the exact string `post-media` in both `supabase.storage.from('post-media')`
calls (upload + `getPublicUrl`) — this matches the bucket id created by the
migration exactly.

The upload error handling now distinguishes two distinct failure modes so
the on-screen message tells you the real problem:
- **Bucket missing** (`404` / "bucket not found") → "Media storage is not
  configured. Please run the latest Supabase migration to create the
  post-media bucket." → apply the migration as above
- **Blocked by policy** (`403` / row-level security / permission denied)
  → "Media upload was blocked by a storage permission policy. Please
  verify the post-media Storage policies are applied." → re-run the
  migration or check the four policies listed above exist in
  **Storage → Policies** for the `post-media` bucket

## Verifying the fix

1. Apply the migration (Option A or B above)
2. In Supabase Dashboard → **Storage**, confirm `post-media` exists and
   is **Public**
3. In Supabase Dashboard → **Storage → Policies**, confirm the four
   policies above exist for `post-media`
4. On the deployed site: log in → **Create Post** → pick a photo or video
   → **Post** → confirm it appears in the feed with the media visible
