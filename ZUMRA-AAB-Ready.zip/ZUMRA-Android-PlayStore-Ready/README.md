# ZUMRA — Android / Play Store project

This project packages the working ZUMRA web application as a native Android app shell.

- App name: ZUMRA
- Application ID: com.zumra.social
- Version: 1.0.0 (versionCode 1)
- Target SDK: 35
- URL loaded by the app: https://incomparable-cobbler-7169a4.netlify.app/

## Build in Android Studio

1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK Platform 35 if Android Studio asks.
3. Run the app on a phone/emulator.
4. For Play Store: Build > Generate Signed Bundle / APK > Android App Bundle.
5. Create a release keystore and keep it safe. The Play Store release should use the signed `.aab` file.

## Important

The app uses the same live ZUMRA backend and Netlify deployment, so existing Supabase accounts and posts remain the same.

Before publishing publicly, update the privacy policy URL, app screenshots, store description, contact email, and Play Console Data safety declarations.
