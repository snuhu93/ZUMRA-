# ZUMRA release rules
